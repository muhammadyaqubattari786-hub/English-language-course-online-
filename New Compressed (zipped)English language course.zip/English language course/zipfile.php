from zipfile import ZipFile
import os

# HTML فائلوں کے نام
lesson_titles = [
    "01_Noun_and_Types.html",
    "02_Pronoun_and_Types.html",
    "03_Verb_and_Types.html",
    "04_Modal_Verbs.html",
    "05_Adjectives_and_Types.html",
    "06_Degrees_of_Adjectives.html",
    "07_Adverb_and_Types.html",
    "08_Position_of_Adverbs.html",
    "09_Formation_of_Adverbs.html",
    "10_Conjunctions_and_Types.html",
    "11_Prepositions_and_Types.html",
    "12_Interjection_and_Types.html",
    "13_Phrase_and_Types.html",
    "14_Clause_and_Types.html",
    "15_Articles.html",
    "16_Infinitives.html",
    "17_Gerunds.html",
    "18_Participles.html",
    "19_Affixes.html",
    "20_Gerund_vs_PresentParticiple.html",
    "21_Antecedent_Errors.html",
    "22_Types_of_Sentences_Meaning.html",
    "23_Types_of_Sentences_Formation.html",
    "24_Conditional_Sentences.html",
    "25_Transitional_Devices.html",
    "26_Cataphora.html",
    "27_Anaphora.html",
    "28_Vowels_and_Consonants.html"
]

# .zip فائل بنائیں
zip_filename = "90Day_English_Course_Lessons.zip"

with ZipFile(zip_filename, 'w') as zipf:
    for title in lesson_titles:
        # سادہ HTML مواد بنائیں
        content = f"<html><head><title>{title}</title></head><body><h1>{title.replace('_', ' ').replace('.html', '')}</h1></body></html>"
        with open(title, 'w', encoding='utf-8') as f:
            f.write(content)
        zipf.write(title)
        os.remove(title)

print(f"{zip_filename} created successfully!")
